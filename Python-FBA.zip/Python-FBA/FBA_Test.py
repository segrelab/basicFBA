# IMPORT A MODEL

from __future__ import print_function
import cobra
#import os


model = cobra.io.load_matlab_model("covert.mat")
#model = cobra.io.load_json_model("RECON3D.json")

model

# OUTPUT OF BASIC PROPERTIES OF THE MODEL 

print(len(model.reactions))
print(len(model.metabolites))
print(len(model.genes))

print(model.objective)

# OUTPUT OF DETAILED LIST OF REACTIONS, METABOLITES.GENES


# Iterate through the the objects in the model
print("Reactions")
print("---------")
for x in model.reactions:
    print("%s : %s" % (x.id, x.reaction))

print("")
print("Metabolites")
print("-----------")
for x in model.metabolites:
    print('%9s : %s' % (x.id, x.formula))

print("")
print("Genes")
print("-----")
for x in model.genes:
    associated_ids = (i.id for i in x.reactions)
    print("%s is associated with reactions: %s" %
          (x.id, "{" + ", ".join(associated_ids) + "}"))
    

# CHANGING UPPER/LOWER BOUNDS TO FLUXES AND OTHER PARAMETERS
reaction_index = 1
model.reactions[reaction_index].upper_bound
original_upper_bound = model.reactions[reaction_index].upper_bound
original_upper_bound

model.reactions[reaction_index].upper_bound = 10
model.reactions[reaction_index].upper_bound

# RUNNING FBA
solution = model.optimize()
print(solution)


# OUTPUTS OF FBA

print(solution.objective_value)

print(solution.status)

print(solution.fluxes)

#model.metabolites.A.summary()


